"""
One LLM interface for both integration options:

  Option A - hosted API: any provider exposing the OpenAI-compatible
             `/chat/completions` endpoint. Pros: strong models, no local hardware.
             Cons: costs money per token, needs internet, models can change or be
             retired (hurting reproducibility), data leaves your machine.
  Option B - local open model via Ollama (also OpenAI-compatible, at
             http://localhost:11434/v1). Pros: free, private, a fixed model file
             (reproducible). Cons: needs RAM (roughly 2-8 GB for 1-8B parameter models),
             slower on CPU, smaller models are less accurate.

Settings come from `.env` (LLM_BACKEND, LLM_BASE_URL, LLM_MODEL, LLM_API_KEY).
With LLM_BACKEND=none, `available` is False and callers skip LLM features.

Every request/response is cached on disk (outputs/results/llm_cache.jsonl), so
re-running an experiment does not repeat paid calls and every reported LLM result
can be audited. The API key is never logged or cached.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import config
from src.utils import Timer, get_logger

logger = get_logger()
CACHE_FILENAME = "llm_cache.jsonl"
_DEFAULT = object()


class LLMClient:
    def __init__(self, backend: str | None = None, base_url: str | None = None,
                 model: str | None = None, api_key: str | None = None,
                 timeout: int | None = None, cache_file=_DEFAULT) -> None:
        self.backend = (backend or config.LLM_BACKEND).lower()
        self.base_url = (base_url or config.LLM_BASE_URL).rstrip("/")
        self.model = model if model is not None else config.LLM_MODEL
        self._api_key = api_key if api_key is not None else config.LLM_API_KEY
        self.timeout = timeout or config.LLM_TIMEOUT_SECONDS
        if cache_file is _DEFAULT:  # resolved at run time so tests can redirect RESULTS_DIR
            cache_file = config.RESULTS_DIR / CACHE_FILENAME
        self.cache_file = Path(cache_file) if cache_file else None
        self._cache: dict[str, dict] = {}
        self.last_error: str | None = None
        if self.cache_file and self.cache_file.exists():
            for line in self.cache_file.read_text(encoding="utf-8").splitlines():
                try:
                    rec = json.loads(line)
                    self._cache[rec["key"]] = rec
                except (json.JSONDecodeError, KeyError):
                    continue

    # -- status --------------------------------------------------------------
    @property
    def configured(self) -> bool:
        return self.backend == "openai" and bool(self.model)

    @property
    def available(self) -> bool:
        """True if configured (a connection is attempted only when chat() is called)."""
        return self.configured

    def describe(self) -> str:
        if not self.configured:
            return "LLM disabled (LLM_BACKEND=none or LLM_MODEL not set in .env)"
        return f"{self.model} via {self.base_url}"

    def check_connection(self) -> tuple[bool, str]:
        """Send a tiny request to verify the endpoint and model respond."""
        if not self.configured:
            return False, self.describe()
        reply = self.chat([{"role": "user", "content": "Reply with the word OK."}], use_cache=False)
        return (reply is not None), (self.last_error or "connected")

    # -- requests -------------------------------------------------------------
    def _key(self, payload: dict) -> str:
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def chat(self, messages: list[dict], temperature: float = config.LLM_TEMPERATURE,
             max_tokens: int = 300, use_cache: bool = True, retries: int = 2) -> str | None:
        """
        Return the assistant's reply text, or None on failure (error in `last_error`).
        temperature=0 asks for the most likely tokens, making outputs as repeatable as
        the provider allows (not guaranteed bit-identical across runs or versions).
        """
        self.last_error = None
        if not self.configured:
            self.last_error = self.describe()
            return None
        payload = {"model": self.model, "messages": messages, "temperature": temperature,
                   "max_tokens": max_tokens}
        key = self._key(payload)
        if use_cache and key in self._cache:
            return self._cache[key]["response"]

        import requests

        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        for attempt in range(retries + 1):
            try:
                with Timer() as t:
                    r = requests.post(f"{self.base_url}/chat/completions", json=payload,
                                      headers=headers, timeout=self.timeout)
                if r.status_code == 429 or r.status_code >= 500:
                    raise RuntimeError(f"HTTP {r.status_code}")
                r.raise_for_status()
                text = r.json()["choices"][0]["message"]["content"]
                rec = {"key": key, "model": self.model, "base_url": self.base_url,
                       "messages": messages, "response": text, "latency_s": round(t.elapsed, 3)}
                self._cache[key] = rec
                if self.cache_file:
                    self.cache_file.parent.mkdir(parents=True, exist_ok=True)
                    with self.cache_file.open("a", encoding="utf-8") as f:
                        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                return text
            except Exception as e:  # network error, timeout, bad JSON, HTTP error
                self.last_error = f"{type(e).__name__}: {str(e)[:200]}"
                if attempt < retries:
                    time.sleep(2 ** attempt)
        logger.warning("LLM request failed: %s", self.last_error)
        return None

    def cached_latency(self, messages: list[dict], temperature: float = config.LLM_TEMPERATURE,
                       max_tokens: int = 300) -> float | None:
        """Latency recorded when this exact request was first made (for timing tables)."""
        payload = {"model": self.model, "messages": messages, "temperature": temperature,
                   "max_tokens": max_tokens}
        rec = self._cache.get(self._key(payload))
        return rec.get("latency_s") if rec else None
