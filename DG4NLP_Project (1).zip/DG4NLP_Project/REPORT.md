# Application of NLP and Large Language Models for Scientific Research Paper Classification and Title Generation Using arXiv Metadata

> **Draft status — read before submitting.**
> * Target length ≈1,500 words (main text, excluding tables and references). **Check the official
>   brief for the real limit, format and referencing style.**
> * Numbers in this draft were measured by `train.py` on the ArXiV Archive 2019 export (§2).
>   If you re-run on the Kaggle file or change `config.py`, replace them with your own values
>   from `outputs/results/`.
> * `[[TODO: ...]]` marks results not yet measured (FLAN-T5, LLM, dense retrieval) and places
>   where **your own critical interpretation** is required. Never fill these with invented values.
> * The draft was prepared with AI assistance. Rewrite it in your own words and acknowledge AI
>   use as your university's policy requires (see the final section).

## 1. Introduction

arXiv receives thousands of new preprints every month, and every submission must be routed to a
subject category and summarised by a title. This project asks how well classical text classifiers
and modern generative models perform two tasks on arXiv metadata: (1) predicting a paper's
*primary category* from its abstract and (2) generating an academic title from the abstract. It
also builds a local Streamlit application that combines these components with paper retrieval and a
retrieval-grounded question-answering assistant. The aim is a reproducible comparison that weighs
accuracy against computational cost and reliability, not just a demonstration.

## 2. Dataset and Preprocessing

The Kaggle arXiv snapshot (Cornell University, n.d.) could not be downloaded in the development
environment, so the loader also supports the ArXiV Archive (Geiger, 2019), a public export of the same
OAI-PMH metadata. Papers first submitted in 2019 were selected (155,464 records; 0 malformed lines).
Title, abstract and categories were complete. `comments` (34.5% missing) and `doi` (78.2%) are
naturally sparse and were not used as features (Figure 4). Cleaning removed 4 withdrawal notices,
20 duplicate abstracts (re-submissions, removed so that the same text cannot appear in two splits)
and 529 abstracts under 20 words, leaving 154,911 papers.

Abstracts have a median of 146 words (5th–95th percentile 54–257) and titles a median of 9 words
(5–16), so a title is roughly a 15:1 compression (Figures 2–3). The label is the **primary
category, i.e. the first category listed**; this held for 100% of records when checked against the
archive's explicit primary field. 53.5% of papers are cross-listed, so single-label classification
discards real ambiguity; multi-label classification is left as future work. The ten most frequent
of the 151 primary categories (41.5% of papers, Figure 1) were kept. To reduce imbalance, each class
was capped at 5,000 randomly sampled papers, lowering the imbalance ratio from 2.6:1 to 1.5:1
(Figure 6). The resulting 41,892 papers were split into stratified train / validation / test sets
(29,324 / 6,284 / 6,284, seed 42), and a fixed, class-balanced subset of 300 test papers was drawn
for comparisons with expensive models.

Two text views were produced. For TF-IDF, text is lower-cased, URLs and inline LaTeX maths are
replaced by placeholder tokens, numbers and stop words are removed, and hyphenated or alphanumeric
terms (*self-supervised*, *gpt-2*, *co2*) are kept as single tokens. For transformers, only
formatting noise is removed, because sub-word tokenisers rely on case, punctuation and function
words. The vocabulary follows Zipf's law (Figure 7): 46.6% of its 98,432 terms occur once, while the
top 20,000 and 50,000 terms cover 95.7% and 98.5% of tokens respectively, which motivated the
vocabulary-size grid. Class-distinctive terms are highly technical (e.g. *strichartz*, *besov* for
math.AP; *qkd*, *vqe* for quant-ph), which suggests lexical features should be strong.

[[TODO: add one or two sentences of your own interpretation of Figures 1–7.]]

## 3. Machine Learning Methodology

Each abstract is represented by sublinear TF-IDF weights (Salton and Buckley, 1988): a term's
weight grows with its frequency in the document and shrinks with the number of documents containing
it, and vectors are L2-normalised. Three linear classifiers suited to sparse, high-dimensional text
were compared: Multinomial Naive Bayes (McCallum and Nigam, 1998), Logistic Regression and a linear
Support Vector Machine (Joachims, 1998), implemented in scikit-learn (Pedregosa et al., 2011).
The vectoriser sits inside a Pipeline and is fitted on training data only. TF-IDF settings
(unigrams vs. unigrams+bigrams, 20k/50k features, min_df 2/5, max_df 0.9) and each classifier's
regularisation were selected by macro-F1 on the validation set. The chosen configuration was then
refitted on train+validation and evaluated once on the test set. Macro-F1 is the primary metric
because it weights every category equally, so a model cannot score well by favouring large classes.

## 4. LLM and Transformer Implementation

**Title generation.** FLAN-T5-base (Chung et al., 2022), an instruction-tuned version of T5
(Raffel et al., 2020), is used zero-shot with the prompt "Generate a concise academic title …",
inputs truncated to 512 tokens and beam search (4 beams, no repeated trigrams, ≤32 new tokens).
Two extractive baselines give a lower bound: the first sentence of the abstract, and the sentence
closest to the abstract's TF-IDF centroid, both truncated to 12 words. Titles differ from summaries:
they are short noun phrases that name the topic or contribution and omit results, so they are more
abstractive, and n-gram overlap with a single reference title (ROUGE; Lin, 2004) is only a partial
measure. Semantic similarity and an *unsupported-word rate* (the share of title content words absent
from the abstract, a simple hallucination proxy) are therefore also reported.

**LLM integration.** One client supports any OpenAI-compatible endpoint, covering both a hosted API
(Option A: strong models, but per-token cost, data leaving the machine and model versions that can
change) and a local model served by Ollama (Option B: free, private and fixed, but limited by laptop
RAM and slower). Credentials come from `.env`, temperature is 0, and every request is cached for
auditability. For classification, the prompt lists the valid categories with descriptions and asks
for JSON (category, one-sentence explanation, verbal confidence). Outputs are parsed defensively and
validated against the label set; unparseable or out-of-set answers count as errors and are never
replaced by a guess. Self-reported confidence is shown only as a qualitative label, because it is
not a calibrated probability. Title prompts are compared in three styles: zero-shot, detailed
instructions (6–15 words, "use only information stated in the abstract") and few-shot with three
examples drawn from the *training* split (Brown et al., 2020).

**Retrieval and RAG.** Papers in train+validation are indexed with all-MiniLM-L6-v2 sentence
embeddings (Reimers and Gurevych, 2019; Wang et al., 2020) and FAISS, with a TF-IDF cosine index as
a fallback. The chatbot retrieves the top five abstracts and answers only from them (Lewis et al.,
2020): with an LLM, citation numbers are checked against the retrieved set; without one, it quotes
the most relevant retrieved sentences. Questions whose best match falls below a measured evidence
threshold are refused.

## 5. Results and Evaluation

**Table 1. Test-set classification (n = 6,284).**

| Model | Accuracy | Macro P | Macro R | Macro F1 | Weighted F1 | ms / abstract* |
|---|---|---|---|---|---|---|
| Multinomial NB | 0.903 | 0.903 | 0.904 | 0.903 | 0.903 | 0.19 |
| Logistic Regression | 0.908 | 0.908 | 0.908 | 0.908 | 0.908 | 0.21 |
| Linear SVM | **0.912** | **0.911** | **0.911** | **0.911** | **0.912** | 0.20 |

\*Batch throughput including text cleaning, on CPU. All three selected configurations use
unigrams+bigrams with 50,000 features. Bigrams helped Naive Bayes most (validation macro-F1 0.897 →
0.904) and the SVM least (0.9055 → 0.9058).

The three models lie within 0.8 percentage points of each other, so the representation matters more
than the classifier. Per-class F1 (Linear SVM) is highest for astro-ph.GA (0.993) and math.AP
(0.981) and lowest for cond-mat.mes-hall (0.797) and cond-mat.mtrl-sci (0.838), which are confused
with each other (`confusion_matrix_linear_svm.png`), as are cs.LG and cs.CV. Of the SVM's 512 test errors, 42.6% predicted one
of the paper's own cross-listed categories, so many "errors" reflect genuinely interdisciplinary
papers rather than model failure.

**Table 2. Same 300 evaluation papers for every model.**

| Model | Accuracy | Macro F1 | Median latency / abstract | Invalid outputs |
|---|---|---|---|---|
| Multinomial NB | 0.887 | 0.888 | ≈1 ms | 0% |
| Logistic Regression | 0.920 | 0.920 | ≈1 ms | 0% |
| Linear SVM | 0.913 | 0.914 | ≈1 ms | 0% |
| LLM zero-shot | [[TODO]] | [[TODO]] | [[TODO]] | [[TODO]] |

With n = 300, differences of about ±3 points are within sampling noise. This is why Logistic
Regression ranks above the SVM here but not on the full test set.

**Table 3. Title generation (300 evaluation papers).**

| Method | ROUGE-1 | ROUGE-2 | ROUGE-L | Similarity† | Unsupported words |
|---|---|---|---|---|---|
| Lead-sentence baseline | 0.270 | 0.117 | 0.234 | 0.244 | 0.2% |
| Centroid-sentence baseline | 0.197 | 0.069 | 0.170 | 0.172 | 0.3% |
| FLAN-T5-base (zero-shot) | [[TODO]] | [[TODO]] | [[TODO]] | [[TODO]] | [[TODO]] |
| LLM zero-shot / instructed / few-shot | [[TODO]] | [[TODO]] | [[TODO]] | [[TODO]] | [[TODO]] |

†Baseline similarity was measured with TF-IDF cosine because sentence-transformers was unavailable
in the development environment. Re-run `python train.py titles` to obtain embedding similarity.

The lead sentence is a surprisingly strong baseline because abstracts often open with the topic, but
its outputs read as sentence fragments, not titles. The baselines' near-zero unsupported-word rates
are true by construction for extractive methods; the metric becomes informative for generative
models.

**Retrieval.** With the TF-IDF index (35,608 papers), known-item search using 300 paper titles as
queries achieved Recall@1 0.957, Recall@10 0.997 and MRR@10 0.974; 76.9% of the top-10 results shared
the query paper's category; the median query time was about 20 ms. Lexical retrieval separates
scientific from everyday questions poorly: the best balanced accuracy was only 0.705, and at the
threshold used (which keeps 95% of scientific queries answerable) only 30% of the 20 off-topic
questions were refused. For example, "banana bread" retrieved physics papers on "banana amplitudes".
[[TODO: rerun `python train.py index` with sentence-transformers and report dense-retrieval results.]]

[[TODO: your critical discussion — accuracy vs. computational cost (milliseconds vs. seconds per
abstract), generalisation (one year, ten classes), reproducibility (fixed local models vs. changing
APIs), hallucination (unsupported-word rate, invalid outputs, refused questions), and possible
pre-training contamination: arXiv text is probably in the training data of FLAN-T5 and most LLMs,
which may inflate their scores.]]

## 6. Application Development

The Streamlit application has six pages: dashboard, classification (with an all-model comparison),
title generation, model comparison, paper explorer and chatbot. It uses cached model loading, input
validation (20 words to 5,000 characters), session state and helpful messages when an artefact is
missing. It reads results only from `outputs/results/`, so it can display only values that were
actually measured, and it works without an LLM. 89 pytest tests cover data loading, cleaning, label
extraction, classifiers, title-generation validation, LLM response parsing, retrieval and citation
validation, and a headless start-up of every page.

## 7. Conclusion and Future Work

TF-IDF with linear models classifies ten arXiv categories with macro-F1 ≈ 0.91 in about a
millisecond per abstract on a CPU; most remaining errors involve neighbouring or cross-listed fields.
[[TODO: conclude on FLAN-T5 / LLM title quality and the LLM-vs-ML comparison once measured.]] Future
work: multi-label prediction using cross-lists, fine-tuning a small transformer classifier, more
years and categories, human evaluation of titles, and hybrid lexical-dense retrieval.

## References

Brown, T. et al. (2020) 'Language models are few-shot learners', *Advances in Neural Information Processing Systems*, 33, pp. 1877–1901.

Chung, H.W. et al. (2022) 'Scaling instruction-finetuned language models', *arXiv preprint* arXiv:2210.11416.

Cornell University (n.d.) *arXiv Dataset*. Kaggle. Available at: https://www.kaggle.com/datasets/Cornell-University/arxiv [[TODO: add access date]].

Geiger, R.S. (2019) *ArXiV Archive: A tidy and complete archive of metadata for papers on arxiv.org*. Zenodo. doi:10.5281/zenodo.1463242.

Joachims, T. (1998) 'Text categorization with support vector machines: learning with many relevant features', in *Machine Learning: ECML-98*. Berlin: Springer, pp. 137–142.

Lewis, P. et al. (2020) 'Retrieval-augmented generation for knowledge-intensive NLP tasks', *Advances in Neural Information Processing Systems*, 33, pp. 9459–9474.

Lin, C.-Y. (2004) 'ROUGE: A package for automatic evaluation of summaries', in *Text Summarization Branches Out*. Barcelona: Association for Computational Linguistics, pp. 74–81.

McCallum, A. and Nigam, K. (1998) 'A comparison of event models for naive Bayes text classification', in *AAAI-98 Workshop on Learning for Text Categorization*, pp. 41–48.

Pedregosa, F. et al. (2011) 'Scikit-learn: Machine learning in Python', *Journal of Machine Learning Research*, 12, pp. 2825–2830.

Raffel, C. et al. (2020) 'Exploring the limits of transfer learning with a unified text-to-text transformer', *Journal of Machine Learning Research*, 21(140), pp. 1–67.

Reimers, N. and Gurevych, I. (2019) 'Sentence-BERT: Sentence embeddings using Siamese BERT-networks', in *Proceedings of EMNLP-IJCNLP 2019*, pp. 3982–3992.

Salton, G. and Buckley, C. (1988) 'Term-weighting approaches in automatic text retrieval', *Information Processing & Management*, 24(5), pp. 513–523.

Wang, W. et al. (2020) 'MiniLM: Deep self-attention distillation for task-agnostic compression of pre-trained transformers', *Advances in Neural Information Processing Systems*, 33, pp. 5776–5788.

[[TODO: verify every reference against the original source before submission.]]

## Acknowledgement of AI assistance

[[TODO: following your university's policy, state which parts (code, design, report text) were
produced with AI assistance (Claude, Anthropic) and how you checked, modified and understood them.]]
