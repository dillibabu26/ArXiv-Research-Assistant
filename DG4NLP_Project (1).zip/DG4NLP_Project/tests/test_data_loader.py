"""Dataset discovery, loading of both formats, malformed records, schema inspection."""

import io
import json
import zipfile

import pandas as pd
import pytest

from src.data_loader import (detect_format, discover_raw_files, inspect_schema, load_raw,
                             repair_arxiv_id)


def _write_jsonl(path, records, extra_lines=()):
    with path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")
        for line in extra_lines:
            f.write(line + "\n")


def _rec(i, year="19"):
    return {"id": f"{year}01.{i:05d}", "title": f"Title {i}", "abstract": f"Abstract {i}",
            "categories": "cs.CL cs.LG", "authors": "X", "update_date": "2019-01-02"}


def test_kaggle_jsonl_skips_malformed_and_incomplete(tmp_path):
    p = tmp_path / "arxiv.json"
    _write_jsonl(p, [_rec(1), _rec(2), _rec(3, year="18")],
                 extra_lines=["{not valid json", json.dumps({"id": "1901.99999"})])
    df, report = load_raw(p, year="2019")
    assert list(df["id"]) == ["1901.00001", "1901.00002"]
    assert report.malformed == 1
    assert report.missing_required == 1
    assert report.filtered_out == 1
    assert set(["id", "title", "abstract", "categories", "source"]) <= set(df.columns)


def test_year_filter_none_keeps_all(tmp_path):
    p = tmp_path / "arxiv.json"
    _write_jsonl(p, [_rec(1), _rec(2, year="18")])
    df, _ = load_raw(p, year=None)
    assert len(df) == 2


def test_archive_tsv_zip_is_mapped_to_standard_schema(tmp_path):
    tsv = ("\tabstract\tarxiv_id\tauthor_text\tcategories\tcomments\tcreated\tdoi\tprimary_cat\ttitle\tupdated\n"
           "0\tSome abstract\t1910.1113699999999\tA B\tcs.LG,cs.CL\t\t2019-10-01\t\tcs.CL\tT1\t2019-10-02\n"
           "1\tOther abstract\t1906.0375\tC D\tquant-ph\t5 pages\t2019-06-01\t\tquant-ph\tT2\t\n")
    p = tmp_path / "arxiv_archive_2019.tsv.zip"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("2019.tsv", tsv)
    assert detect_format(p) == "archive_tsv"
    df, report = load_raw(p, year="2019")
    assert list(df["id"]) == ["1910.11137", "1906.03750"]
    # explicit primary category is moved to the front
    assert df.loc[0, "categories"] == "cs.CL cs.LG"
    assert df.loc[1, "comments"] == "5 pages"
    assert pd.isna(df.loc[0, "comments"])


def test_repair_arxiv_id():
    assert repair_arxiv_id("1906.0375") == "1906.03750"
    assert repair_arxiv_id("1910.1113699999999") == "1910.11137"
    assert repair_arxiv_id("math/0101001") == "math/0101001"


def test_detect_format_rejects_unrelated_files(tmp_path):
    p = tmp_path / "other.csv"
    p.write_text("a,b\n1,2\n")
    with pytest.raises(ValueError):
        detect_format(p)


def test_discover_and_missing_dataset_message(tmp_path, monkeypatch):
    assert discover_raw_files(tmp_path) == []
    import src.data_loader as dl
    monkeypatch.setattr(dl, "discover_raw_files", lambda: [])
    with pytest.raises(FileNotFoundError, match="No dataset found"):
        dl.load_raw()


def test_inspect_schema_counts_empty_strings_as_missing():
    df = pd.DataFrame({"id": ["1", "2", "2"], "abstract": ["a", "", "a"], "doi": [None, "x", None]})
    s = inspect_schema(df)
    assert s["missing"]["abstract"] == 1
    assert s["missing"]["doi"] == 2
    assert s["duplicate_ids"] == 1
    assert s["n_rows"] == 3
